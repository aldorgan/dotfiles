#!/bin/bash
chown root ./light
chmod a+xs ./light
